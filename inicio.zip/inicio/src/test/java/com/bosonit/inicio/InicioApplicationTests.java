package com.bosonit.inicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
